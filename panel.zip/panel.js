const express = require("express");
const session = require("express-session");
const path = require("path");
const bodyParser = require("body-parser");
const fs = require("fs");

const app = express();
const PORT = 3000;

// ======= Middleware =======
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(express.static("views"));

app.use(
  session({
    secret: "casa-og-panel",
    resave: false,
    saveUninitialized: true
  })
);

// ======= Simple user database (file based) =======
const USERS_FILE = "users.json";

function loadUsers() {
  if (!fs.existsSync(USERS_FILE)) {
    fs.writeFileSync(USERS_FILE, "[]");
  }
  return JSON.parse(fs.readFileSync(USERS_FILE));
}

function saveUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

// ======= Routes =======

// LOGIN PAGE
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views/login.html"));
});

// REGISTER PAGE
app.get("/register", (req, res) => {
  res.sendFile(path.join(__dirname, "views/register.html"));
});

// DASHBOARD
app.get("/dashboard", (req, res) => {
  if (!req.session.user) return res.redirect("/");
  res.sendFile(path.join(__dirname, "views/dashboard.html"));
});

// LOGOUT
app.get("/logout", (req, res) => {
  req.session.destroy();
  res.redirect("/");
});

// ======= Auth Logic =======

// Register
app.post("/register", (req, res) => {
  const { username, password } = req.body;
  let users = loadUsers();

  if (users.find(u => u.username === username)) {
    return res.send("User already exists!");
  }

  users.push({ username, password });
  saveUsers(users);

  res.redirect("/");
});

// Login
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  let users = loadUsers();

  let user = users.find(u => u.username === username && u.password === password);
  if (!user) return res.send("Wrong login!");

  req.session.user = user;
  res.redirect("/dashboard");
});

// ======= Start Panel =======
app.listen(PORT, () => {
  console.log("Casa-OG