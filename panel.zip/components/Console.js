function Console() {
    const [command, setCommand] = React.useState('');
    const [logs, setLogs] = React.useState([
        { id: 1, type: 'info', text: '[17:49:10] [Server thread/INFO]: Starting minecraft server version 1.20.4' },
        { id: 2, type: 'info', text: '[17:49:11] [Server thread/INFO]: Loading properties' },
        { id: 3, type: 'info', text: '[17:49:11] [Server thread/INFO]: Default game type: SURVIVAL' },
        { id: 4, type: 'info', text: '[17:49:11] [Server thread/INFO]: Generating keypair' },
        { id: 5, type: 'warn', text: '[17:49:12] [Server thread/WARN]: Ambiguity between arguments [teleport, destination] and [teleport, targets] with inputs: [Player, 0123, @e, dd12be42-52a9-4a91-a8a1-11c01e2c1b09]' },
        { id: 6, type: 'info', text: '[17:49:15] [Server thread/INFO]: Preparing level "world"' },
        { id: 7, type: 'info', text: '[17:49:22] [Server thread/INFO]: Done (12.450s)! For help, type "help"' },
    ]);

    const handleSend = (e) => {
        e.preventDefault();
        if(!command) return;
        setLogs([...logs, { id: Date.now(), type: 'input', text: `> ${command}` }]);
        setCommand('');
        // Mock server response
        setTimeout(() => {
             setLogs(prev => [...prev, { id: Date.now() + 1, type: 'info', text: `[Server thread/INFO]: Unknown command. Type "help" for help.` }]);
        }, 500);
    };

    return (
        <div className="flex flex-col h-[600px] bg-[var(--bg-console)] rounded-lg border border-[var(--border-color)] overflow-hidden">
            <div className="flex-1 p-4 overflow-y-auto font-mono text-sm space-y-1">
                {logs.map(log => (
                    <div key={log.id} className={`${log.type === 'warn' ? 'text-yellow-400' : log.type === 'error' ? 'text-red-400' : log.type === 'input' ? 'text-slate-400' : 'text-slate-200'}`}>
                        {log.text}
                    </div>
                ))}
            </div>
            <form onSubmit={handleSend} className="p-2 bg-slate-900 border-t border-[var(--border-color)] flex gap-2">
                <div className="icon-terminal text-slate-500 my-auto"></div>
                <input 
                    type="text" 
                    value={command}
                    onChange={e => setCommand(e.target.value)}
                    className="flex-1 bg-transparent border-none outline-none text-white placeholder-slate-600 focus:ring-0" 
                    placeholder="Type a command..." 
                />
                <button type="submit" className="btn btn-primary btn-sm">Send</button>
            </form>
        </div>
    );
}