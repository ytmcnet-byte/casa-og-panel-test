function AuthLayout({ children, title, subtitle }) {
    return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-[url('https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center">
            <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm"></div>
            
            <div className="relative w-full max-w-md bg-[var(--bg-card)] border border-[var(--border-color)] rounded-xl shadow-2xl p-8">
                <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-[var(--primary-color)] mb-4">
                        <div className="icon-server text-white text-2xl"></div>
                    </div>
                    <h1 className="text-2xl font-bold text-white">{title}</h1>
                    <p className="text-[var(--text-secondary)] mt-2">{subtitle}</p>
                </div>
                {children}
            </div>
        </div>
    );
}