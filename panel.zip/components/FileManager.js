function FileManager() {
    const files = [
        { name: 'server.properties', size: '1.2 KB', type: 'file', date: '2025-01-14' },
        { name: 'banned-ips.json', size: '2 B', type: 'file', date: '2025-01-10' },
        { name: 'banned-players.json', size: '2 B', type: 'file', date: '2025-01-10' },
        { name: 'ops.json', size: '2 B', type: 'file', date: '2025-01-10' },
        { name: 'whitelist.json', size: '2 B', type: 'file', date: '2025-01-10' },
        { name: 'world', size: '-', type: 'folder', date: '2025-01-15' },
        { name: 'logs', size: '-', type: 'folder', date: '2025-01-15' },
        { name: 'plugins', size: '-', type: 'folder', date: '2025-01-12' },
        { name: 'eula.txt', size: '16 B', type: 'file', date: '2025-01-10' },
        { name: 'spigot.jar', size: '34 MB', type: 'file', date: '2025-01-10' },
    ];

    return (
        <div className="card">
            <div className="p-4 border-b border-[var(--border-color)] flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-slate-400">
                    <div className="icon-home text-slate-300"></div> / <span className="text-white">container</span> /
                </div>
                <div className="flex gap-2">
                    <button className="btn btn-secondary btn-sm">
                        <div className="icon-cloud-upload w-4 h-4"></div> Upload
                    </button>
                    <button className="btn btn-primary btn-sm">
                        <div className="icon-file-plus w-4 h-4"></div> New File
                    </button>
                </div>
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="text-xs font-semibold text-slate-500 bg-slate-900/50 uppercase tracking-wider">
                            <th className="px-4 py-3">Name</th>
                            <th className="px-4 py-3">Size</th>
                            <th className="px-4 py-3">Last Modified</th>
                            <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--border-color)]">
                        {files.sort((a,b) => (a.type === 'folder' ? -1 : 1)).map((file, idx) => (
                            <tr key={idx} className="hover:bg-slate-800/50 group transition-colors">
                                <td className="px-4 py-3">
                                    <div className="flex items-center gap-3">
                                        <div className={`${file.type === 'folder' ? 'icon-folder text-yellow-500' : 'icon-file-text text-slate-400'} text-lg`}></div>
                                        <span className={`text-sm ${file.type === 'folder' ? 'font-semibold text-white' : 'text-slate-200'}`}>
                                            {file.name}
                                        </span>
                                    </div>
                                </td>
                                <td className="px-4 py-3 text-sm text-slate-400">{file.size}</td>
                                <td className="px-4 py-3 text-sm text-slate-400">{file.date}</td>
                                <td className="px-4 py-3 text-right">
                                    <button className="text-slate-500 hover:text-white p-1">
                                        <div className="icon-more-vertical w-4 h-4"></div>
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}