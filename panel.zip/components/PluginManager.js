function PluginManager() {
    const plugins = [
        { name: 'EssentialsX', desc: 'Essential commands for your server', version: '2.20.1', installed: true },
        { name: 'Vault', desc: 'Permissions and Economy API', version: '1.7.3', installed: true },
        { name: 'WorldEdit', desc: 'In-game world editor', version: '7.3.0', installed: false },
        { name: 'LuckPerms', desc: 'Advanced permissions plugin', version: '5.4.102', installed: false },
        { name: 'ClearLag', desc: 'Reduce lag on your server', version: '3.2.2', installed: false },
    ];

    return (
        <div className="space-y-4">
            <div className="flex gap-4 mb-6">
                <div className="relative flex-1">
                    <div className="absolute left-3 top-2.5 icon-search text-slate-400"></div>
                    <input type="text" placeholder="Search Spigot/Bukkit plugins..." className="form-input pl-10" />
                </div>
                <select className="form-input w-48">
                    <option>Spigot</option>
                    <option>Paper</option>
                    <option>Purpur</option>
                </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {plugins.map((plugin, idx) => (
                    <div key={idx} className="card p-4 flex items-start justify-between">
                        <div>
                            <div className="flex items-center gap-2">
                                <h3 className="font-bold text-white">{plugin.name}</h3>
                                {plugin.installed && <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded">Installed</span>}
                            </div>
                            <p className="text-sm text-slate-400 mt-1">{plugin.desc}</p>
                            <div className="text-xs text-slate-500 mt-2">Latest: v{plugin.version}</div>
                        </div>
                        <button className={`btn btn-sm ${plugin.installed ? 'btn-danger' : 'btn-primary'}`}>
                            {plugin.installed ? 'Uninstall' : 'Install'}
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
}