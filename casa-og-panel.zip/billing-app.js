class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) { return { hasError: true }; }
  componentDidCatch(error, errorInfo) { console.error(error, errorInfo); }
  render() { if (this.state.hasError) return <h1>Something went wrong.</h1>; return this.props.children; }
}

function BillingPage() {
    const invoices = [
        { id: 'INV-2024-001', date: '2025-01-01', amount: '$15.00', status: 'paid', description: 'Server Hosting - Monthly' },
        { id: 'INV-2023-128', date: '2024-12-01', amount: '$15.00', status: 'paid', description: 'Server Hosting - Monthly' },
        { id: 'INV-2023-115', date: '2024-11-01', amount: '$10.00', status: 'paid', description: 'Credit Top-up' },
    ];

    return (
        <Layout activePage="billing">
            <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white mb-2">Billing & Finance</h1>
                    <p className="text-slate-400">Manage your account balance and view invoices.</p>
                </div>
                <div className="flex gap-3">
                    <button className="btn btn-secondary">
                        <div className="icon-history w-4 h-4"></div> History
                    </button>
                    <button className="btn btn-primary">
                        <div className="icon-plus w-4 h-4"></div> Add Funds
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="card bg-gradient-to-br from-[var(--primary-color)] to-purple-600 border-none">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-purple-100 font-medium">Account Balance</h3>
                        <div className="icon-wallet text-purple-200"></div>
                    </div>
                    <div className="text-3xl font-bold text-white mb-1">$45.50</div>
                    <div className="text-purple-200 text-sm">Available Credits</div>
                </div>

                <div className="card">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-slate-400 font-medium">Monthly Cost</h3>
                        <div className="icon-calendar-clock text-slate-500"></div>
                    </div>
                    <div className="text-3xl font-bold text-white mb-1">$15.00</div>
                    <div className="text-slate-500 text-sm">Next payment due in 14 days</div>
                </div>

                <div className="card">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-slate-400 font-medium">Active Services</h3>
                        <div className="icon-server text-slate-500"></div>
                    </div>
                    <div className="text-3xl font-bold text-white mb-1">3</div>
                    <div className="text-slate-500 text-sm">Servers running</div>
                </div>
            </div>

            <div className="card">
                <h3 className="text-lg font-bold text-white mb-6">Recent Invoices</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="border-b border-[var(--border-color)] text-slate-400 text-sm">
                                <th className="px-4 py-3 font-medium">Invoice ID</th>
                                <th className="px-4 py-3 font-medium">Date</th>
                                <th className="px-4 py-3 font-medium">Description</th>
                                <th className="px-4 py-3 font-medium">Amount</th>
                                <th className="px-4 py-3 font-medium">Status</th>
                                <th className="px-4 py-3 font-medium text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-[var(--border-color)]">
                            {invoices.map(invoice => (
                                <tr key={invoice.id} className="text-sm hover:bg-slate-800/30 transition-colors">
                                    <td className="px-4 py-4 text-white font-mono">{invoice.id}</td>
                                    <td className="px-4 py-4 text-slate-400">{invoice.date}</td>
                                    <td className="px-4 py-4 text-slate-300">{invoice.description}</td>
                                    <td className="px-4 py-4 text-white font-bold">{invoice.amount}</td>
                                    <td className="px-4 py-4">
                                        <span className="px-2 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 uppercase">
                                            {invoice.status}
                                        </span>
                                    </td>
                                    <td className="px-4 py-4 text-right">
                                        <button className="text-slate-400 hover:text-[var(--primary-color)] transition-colors">
                                            <div className="icon-download w-4 h-4"></div>
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                <div className="card">
                     <h3 className="text-lg font-bold text-white mb-4">Payment Methods</h3>
                     <div className="flex items-center justify-between p-4 border border-[var(--border-color)] rounded-lg bg-slate-900/50 mb-3">
                         <div className="flex items-center gap-3">
                             <div className="w-10 h-6 bg-slate-700 rounded flex items-center justify-center text-xs font-bold tracking-tighter">VISA</div>
                             <div>
                                 <div className="text-sm font-medium text-white">Visa ending in 4242</div>
                                 <div className="text-xs text-slate-500">Expires 12/28</div>
                             </div>
                         </div>
                         <button className="text-slate-400 hover:text-red-400"><div className="icon-trash w-4 h-4"></div></button>
                     </div>
                     <button className="btn btn-secondary w-full text-sm mt-2">
                        <div className="icon-credit-card w-4 h-4"></div> Add New Card
                     </button>
                </div>
                
                <div className="card bg-[var(--primary-color)] bg-opacity-10 border-[var(--primary-color)] border-opacity-20">
                    <h3 className="text-lg font-bold text-white mb-2">Upgrade to Pro</h3>
                    <p className="text-slate-300 text-sm mb-4">Get priority CPU access, NVMe storage, and dedicated support for your game servers.</p>
                    <button className="btn btn-primary w-full">View Plans</button>
                </div>
            </div>
        </Layout>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><BillingPage /></ErrorBoundary>);