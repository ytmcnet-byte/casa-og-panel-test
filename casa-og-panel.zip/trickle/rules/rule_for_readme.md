When updating the project
- Always check if the changes require updating the `trickle/notes/README.md` file.
- Keep the README content concise and up-to-date with the project structure and features.