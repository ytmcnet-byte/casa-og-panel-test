# Game Server Dashboard (casa-og-panel)

A modern, responsive dashboard for managing game servers, similar to Pterodactyl.

## Features
- **Authentication**: Login and Registration pages.
- **Dashboard**: Overview of available servers.
- **Server Management**: Console, File Manager, Databases, Plugins, and more.
- **Billing**: Manage funds, view invoices, and payment methods.
- **Admin**: Multi-node management system.

## Structure
- `index.html`: Login page.
- `register.html`: Registration page.
- `dashboard.html`: Main server list.
- `server.html`: Individual server management interface.
- `billing.html`: Billing dashboard.
- `admin.html`: Admin node management.