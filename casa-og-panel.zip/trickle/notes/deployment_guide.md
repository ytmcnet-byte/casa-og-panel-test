# Deployment Guide: Running casa-og-panel with NPM

This guide explains how to install and run the panel on a VPS using **Node.js** and **npm**.

## 1. Prerequisites (Install Node.js)
First, you need Node.js and npm installed on your VPS.
```bash
# Update system
sudo apt update

# Install Node.js (Version 18 or higher recommended)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node -v
npm -v
```

## 2. Getting the Code
**Option A: Upload Files**
Upload your project files to `/var/www/casa-og-panel` (or any folder you prefer).

**Option B: Git Clone**
```bash
git clone https://github.com/your-username/casa-og-panel.git
cd casa-og-panel
```

## 3. Installation & Starting the Panel

1.  **Navigate to the folder:**
    ```bash
    cd /path/to/casa-og-panel
    ```

2.  **Install Dependencies:**
    ```bash
    npm install
    ```

3.  **Start the Panel:**
    To run it immediately (it will stop if you close the terminal):
    ```bash
    npm start
    ```
    *The panel is now running on port 3000.*

4.  **Keep it Running (Background Process):**
    To keep it running after you disconnect, use `pm2`.
    ```bash
    # Install pm2 globally
    sudo npm install -g pm2

    # Start the app
    pm2 start npm --name "casa-panel" -- start

    # Save the list so it auto-starts on reboot
    pm2 save
    pm2 startup
    ```

## 4. User Management
Since this is currently a **Frontend Prototype**, it simulates a backend.
- **Login:** You can enter *any* email/password on the login page to access the dashboard.
- **Users:** No database is needed yet. When you are ready for a real backend, you will connect this frontend to an API.

## 5. Port Forwarding (Firewall)
You need to open the port that the app is running on (default `3000` in this config) and port `80` if you want to use a reverse proxy later.

### Open Port 3000
```bash
sudo ufw allow 3000/tcp
```

### Accessing the Panel
Visit: `http://your-vps-ip:3000`

---
### Optional: Run on Port 80 (Standard HTTP)
If you want to access it without `:3000` (just the IP), you can redirect port 80 to 3000 or use Nginx as a proxy (Recommended), or change the start script.

**Quick way (Change port in package.json):**
1. Edit `package.json`
2. Change `"start": "serve -s . -l 3000"` to `"start": "serve -s . -l 80"`
3. Run with sudo: `sudo npm start`