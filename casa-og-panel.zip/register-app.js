class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) { return { hasError: true }; }
  componentDidCatch(error, errorInfo) { console.error(error, errorInfo); }
  render() { if (this.state.hasError) return <h1>Something went wrong.</h1>; return this.props.children; }
}

function RegisterPage() {
    const handleRegister = (e) => {
        e.preventDefault();
        // Mock register
        window.location.href = 'dashboard.html';
    };

    return (
        <AuthLayout title="Create Account" subtitle="Get started with your game server">
            <form onSubmit={handleRegister} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-300 mb-1">First Name</label>
                        <input type="text" className="form-input" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-300 mb-1">Last Name</label>
                        <input type="text" className="form-input" required />
                    </div>
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Username</label>
                    <input type="text" className="form-input" required />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Email</label>
                    <input type="email" className="form-input" placeholder="user@example.com" required />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Password</label>
                    <input type="password" className="form-input" placeholder="••••••••" required />
                </div>
                
                <button type="submit" className="btn btn-primary w-full mt-2">
                    Create Account
                </button>
            </form>
            
            <div className="mt-6 text-center text-sm text-slate-400">
                Already have an account? 
                <a href="index.html" className="text-[var(--primary-color)] hover:underline ml-1">Sign In</a>
            </div>
        </AuthLayout>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><RegisterPage /></ErrorBoundary>);