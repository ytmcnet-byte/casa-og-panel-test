class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) { return { hasError: true }; }
  componentDidCatch(error, errorInfo) { console.error(error, errorInfo); }
  render() { if (this.state.hasError) return <h1>Something went wrong.</h1>; return this.props.children; }
}

function ServerPage() {
    const [activeTab, setActiveTab] = React.useState('console');
    const [status, setStatus] = React.useState('online');

    const tabs = [
        { id: 'console', label: 'Console', icon: 'icon-terminal' },
        { id: 'files', label: 'File Manager', icon: 'icon-folder-open' },
        { id: 'databases', label: 'Databases', icon: 'icon-database' },
        { id: 'plugins', label: 'Plugins', icon: 'icon-puzzle' },
        { id: 'settings', label: 'Settings', icon: 'icon-settings' },
    ];

    // Mock CPU chart
    React.useEffect(() => {
        if (activeTab === 'console' && window.Chart) {
            const ctx = document.getElementById('cpuChart');
            if (ctx) {
                new window.Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: Array(20).fill(''),
                        datasets: [{
                            label: 'CPU Usage',
                            data: Array(20).fill(0).map(() => Math.random() * 30 + 10),
                            borderColor: '#6366f1',
                            tension: 0.4,
                            pointRadius: 0,
                            borderWidth: 2,
                            fill: true,
                            backgroundColor: 'rgba(99, 102, 241, 0.1)'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            y: { beginAtZero: true, max: 100, display: false },
                            x: { display: false }
                        }
                    }
                });
            }
        }
    }, [activeTab]);

    return (
        <Layout activePage="servers">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-4">
                <div>
                    <div className="flex items-center gap-3 mb-1">
                        <h1 className="text-2xl font-bold text-white">Survival SMP Season 4</h1>
                        <span className={`px-2 py-0.5 rounded text-xs font-bold uppercase tracking-wide ${status === 'online' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                            {status}
                        </span>
                    </div>
                    <div className="text-sm text-slate-400 font-mono">192.168.1.1:25565</div>
                </div>
                
                <div className="flex gap-2">
                    <button className="btn bg-emerald-600 hover:bg-emerald-500 text-white" onClick={() => setStatus('online')}>Start</button>
                    <button className="btn bg-yellow-600 hover:bg-yellow-500 text-white" onClick={() => setStatus('restarting')}>Restart</button>
                    <button className="btn bg-red-600 hover:bg-red-500 text-white" onClick={() => setStatus('offline')}>Stop</button>
                </div>
            </div>

            <div className="border-b border-[var(--border-color)] mb-6 overflow-x-auto">
                <div className="flex space-x-1 min-w-max">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`nav-tab flex items-center gap-2 ${activeTab === tab.id ? 'active' : ''}`}
                        >
                            <div className={`${tab.icon} w-4 h-4`}></div>
                            {tab.label}
                        </button>
                    ))}
                </div>
            </div>

            {activeTab === 'console' && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 space-y-4">
                        <Console />
                    </div>
                    <div className="space-y-4">
                        <div className="card p-4">
                            <h3 className="font-bold text-white mb-4 flex items-center gap-2">
                                <div className="icon-activity w-4 h-4"></div> Resources
                            </h3>
                            <div className="space-y-4">
                                <div>
                                    <div className="flex justify-between text-xs text-slate-400 mb-1">
                                        <span>CPU Load</span>
                                        <span>42%</span>
                                    </div>
                                    <div className="h-16 w-full bg-slate-900 rounded overflow-hidden">
                                        <canvas id="cpuChart"></canvas>
                                    </div>
                                </div>
                                <div>
                                    <div className="flex justify-between text-xs text-slate-400 mb-1">
                                        <span>Memory (RAM)</span>
                                        <span>2.4 GB / 8 GB</span>
                                    </div>
                                    <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                                        <div className="h-full bg-purple-500" style={{width: '30%'}}></div>
                                    </div>
                                </div>
                                <div>
                                    <div className="flex justify-between text-xs text-slate-400 mb-1">
                                        <span>Disk Space</span>
                                        <span>15 GB / 50 GB</span>
                                    </div>
                                    <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                                        <div className="h-full bg-orange-500" style={{width: '30%'}}></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="card p-4">
                             <h3 className="font-bold text-white mb-4">Server Details</h3>
                             <div className="space-y-2 text-sm">
                                 <div className="flex justify-between border-b border-slate-700/50 pb-2">
                                     <span className="text-slate-400">Node</span>
                                     <span className="text-white">Node-NYC-01</span>
                                 </div>
                                 <div className="flex justify-between border-b border-slate-700/50 pb-2">
                                     <span className="text-slate-400">Docker Image</span>
                                     <span className="text-white">ghcr.io/pterodactyl/java:17</span>
                                 </div>
                                 <div className="flex justify-between pt-1">
                                     <span className="text-slate-400">Uptime</span>
                                     <span className="text-white">2d 14h 32m</span>
                                 </div>
                             </div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'files' && <FileManager />}
            
            {activeTab === 'plugins' && <PluginManager />}

            {activeTab === 'databases' && (
                <div className="card p-8 text-center">
                    <div className="icon-database text-6xl text-slate-600 mx-auto mb-4"></div>
                    <h3 className="text-xl font-bold text-white mb-2">My Databases</h3>
                    <p className="text-slate-400 mb-6">Create and manage MySQL databases for your server.</p>
                    <button className="btn btn-primary mx-auto">
                        <div className="icon-plus-circle w-5 h-5"></div>
                        New Database
                    </button>
                </div>
            )}
            
            {activeTab === 'settings' && (
                <div className="card p-6 max-w-2xl">
                    <h3 className="text-xl font-bold text-white mb-6">SFTP Details</h3>
                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-1">Connection Address</label>
                            <div className="flex gap-2">
                                <input type="text" readOnly value="sftp://node-nyc-01.panel.io:2022" className="form-input bg-slate-900 text-slate-300" />
                                <button className="btn btn-secondary"><div className="icon-copy w-4 h-4"></div></button>
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-1">Username</label>
                            <div className="flex gap-2">
                                <input type="text" readOnly value="alex.529a1b" className="form-input bg-slate-900 text-slate-300" />
                                <button className="btn btn-secondary"><div className="icon-copy w-4 h-4"></div></button>
                            </div>
                        </div>
                        <div className="pt-4 border-t border-[var(--border-color)] mt-4">
                            <h4 className="text-red-400 font-bold mb-2">Danger Zone</h4>
                            <button className="btn btn-danger w-full">Reinstall Server</button>
                        </div>
                    </div>
                </div>
            )}
        </Layout>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><ServerPage /></ErrorBoundary>);