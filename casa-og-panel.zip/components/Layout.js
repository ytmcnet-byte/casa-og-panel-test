function Layout({ children, activePage = 'dashboard' }) {
    const [sidebarOpen, setSidebarOpen] = React.useState(true);

    const toggleSidebar = () => setSidebarOpen(!sidebarOpen);

    const menuItems = [
        { id: 'dashboard', icon: 'icon-layout-dashboard', label: 'Dashboard', href: 'dashboard.html' },
        { id: 'servers', icon: 'icon-server', label: 'My Servers', href: 'dashboard.html' },
        { id: 'billing', icon: 'icon-credit-card', label: 'Billing', href: 'billing.html' },
        { id: 'admin', icon: 'icon-shield-check', label: 'Admin Nodes', href: 'admin.html' },
        { id: 'account', icon: 'icon-user', label: 'Account', href: '#' },
    ];

    return (
        <div className="flex min-h-screen" data-name="layout" data-file="components/Layout.js">
            {/* Sidebar */}
            <aside className={`fixed inset-y-0 left-0 z-50 bg-[var(--bg-card)] border-r border-[var(--border-color)] transition-all duration-300 ${sidebarOpen ? 'w-64' : 'w-20'} overflow-hidden`}>
                <div className="flex items-center gap-3 p-6 h-16 border-b border-[var(--border-color)]">
                    <div className="w-8 h-8 rounded bg-[var(--primary-color)] flex items-center justify-center shrink-0">
                        <div className="icon-gamepad-2 text-white"></div>
                    </div>
                    {sidebarOpen && <span className="font-bold text-xl tracking-tight">casa-og-panel</span>}
                </div>

                <nav className="p-4 space-y-1">
                    {menuItems.map(item => (
                        <a 
                            key={item.id} 
                            href={item.href}
                            className={`sidebar-link group ${activePage === item.id ? 'active' : ''}`}
                            title={!sidebarOpen ? item.label : ''}
                        >
                            <div className={`${item.icon} text-xl shrink-0`}></div>
                            {sidebarOpen && <span>{item.label}</span>}
                        </a>
                    ))}
                </nav>

                <div className="absolute bottom-0 w-full p-4 border-t border-[var(--border-color)]">
                    <button className="sidebar-link w-full text-red-400 hover:text-red-300 hover:bg-red-500/10">
                        <div className="icon-log-out text-xl shrink-0"></div>
                        {sidebarOpen && <span>Logout</span>}
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
                {/* Header */}
                <header className="h-16 bg-[var(--bg-body)]/80 backdrop-blur border-b border-[var(--border-color)] sticky top-0 z-40 px-6 flex items-center justify-between">
                    <button onClick={toggleSidebar} className="p-2 rounded-md hover:bg-slate-800 text-slate-400">
                        <div className="icon-menu text-xl"></div>
                    </button>

                    <div className="flex items-center gap-4">
                        <button className="p-2 rounded-full hover:bg-slate-800 text-slate-400 relative">
                            <div className="icon-bell text-xl"></div>
                            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
                        </button>
                        <div className="flex items-center gap-3 pl-4 border-l border-[var(--border-color)]">
                            <div className="text-right hidden sm:block">
                                <div className="text-sm font-medium text-white">Alex Gamer</div>
                                <div className="text-xs text-slate-400">Admin</div>
                            </div>
                            <div className="w-9 h-9 rounded-full bg-slate-700 overflow-hidden">
                                <img src="https://ui-avatars.com/api/?name=Alex+Gamer&background=6366f1&color=fff" alt="User" />
                            </div>
                        </div>
                    </div>
                </header>

                {/* Page Content */}
                <div className="p-6">
                    {children}
                </div>
            </main>
        </div>
    );
}