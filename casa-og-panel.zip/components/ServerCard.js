function ServerCard({ server }) {
    const getStatusColor = (status) => {
        switch(status) {
            case 'online': return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
            case 'offline': return 'bg-red-500/10 text-red-500 border-red-500/20';
            case 'starting': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
            default: return 'bg-slate-500/10 text-slate-500';
        }
    };

    return (
        <div className="card hover:border-[var(--primary-color)] transition-colors group" data-name="server-card">
            <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-4">
                    <div className={`w-3 h-12 rounded-full ${server.status === 'online' ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
                    <div>
                        <h3 className="text-lg font-bold text-white group-hover:text-[var(--primary-color)] transition-colors">
                            <a href={`server.html?id=${server.id}`}>{server.name}</a>
                        </h3>
                        <div className="text-sm text-slate-400 font-mono">{server.ip}:{server.port}</div>
                    </div>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-bold border ${getStatusColor(server.status)}`}>
                    {server.status.toUpperCase()}
                </div>
            </div>

            <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-slate-900/50 p-2 rounded">
                    <div className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                        <div className="icon-cpu text-xs"></div> CPU
                    </div>
                    <div className="text-sm font-mono text-slate-200">{server.usage.cpu}%</div>
                    <div className="w-full h-1 bg-slate-700 rounded-full mt-1 overflow-hidden">
                        <div className="h-full bg-blue-500" style={{width: `${server.usage.cpu}%`}}></div>
                    </div>
                </div>
                <div className="bg-slate-900/50 p-2 rounded">
                    <div className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                        <div className="icon-memory-stick text-xs"></div> RAM
                    </div>
                    <div className="text-sm font-mono text-slate-200">{server.usage.ram}</div>
                    <div className="w-full h-1 bg-slate-700 rounded-full mt-1 overflow-hidden">
                        <div className="h-full bg-purple-500" style={{width: '45%'}}></div>
                    </div>
                </div>
                <div className="bg-slate-900/50 p-2 rounded">
                    <div className="text-xs text-slate-500 mb-1 flex items-center gap-1">
                        <div className="icon-hard-drive text-xs"></div> DISK
                    </div>
                    <div className="text-sm font-mono text-slate-200">{server.usage.disk}</div>
                    <div className="w-full h-1 bg-slate-700 rounded-full mt-1 overflow-hidden">
                        <div className="h-full bg-orange-500" style={{width: '20%'}}></div>
                    </div>
                </div>
            </div>

            <div className="flex items-center justify-between mt-2 pt-4 border-t border-[var(--border-color)]">
                <div className="text-xs text-slate-500">
                    <span className="font-semibold text-slate-400">{server.game}</span> • {server.node}
                </div>
                <a href={`server.html?id=${server.id}`} className="btn btn-secondary btn-sm">
                    Manage
                    <div className="icon-arrow-right w-4 h-4"></div>
                </a>
            </div>
        </div>
    );
}