class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) { return { hasError: true }; }
  componentDidCatch(error, errorInfo) { console.error(error, errorInfo); }
  render() { if (this.state.hasError) return <h1>Something went wrong.</h1>; return this.props.children; }
}

function AdminPage() {
    const nodes = [
        { 
            id: 1, 
            name: 'Node-NYC-01', 
            location: 'New York, USA', 
            status: 'online', 
            ip: '192.168.1.100', 
            ram: { used: 48, total: 64 },
            disk: { used: 210, total: 1000 },
            servers: 142
        },
        { 
            id: 2, 
            name: 'Node-LON-02', 
            location: 'London, UK', 
            status: 'online', 
            ip: '192.168.1.101', 
            ram: { used: 52, total: 64 },
            disk: { used: 450, total: 1000 },
            servers: 156
        },
        { 
            id: 3, 
            name: 'Node-SIN-01', 
            location: 'Singapore', 
            status: 'offline', 
            ip: '192.168.1.102', 
            ram: { used: 0, total: 32 },
            disk: { used: 0, total: 500 },
            servers: 0
        },
    ];

    return (
        <Layout activePage="admin">
            <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white mb-2">Node Management</h1>
                    <p className="text-slate-400">Monitor and configure your infrastructure nodes.</p>
                </div>
                <button className="btn btn-primary">
                    <div className="icon-server w-4 h-4"></div> Deploy New Node
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                 <div className="card">
                     <div className="text-slate-400 text-sm font-medium mb-1">Total Active Nodes</div>
                     <div className="text-3xl font-bold text-white">2 <span className="text-slate-500 text-lg font-normal">/ 3</span></div>
                 </div>
                 <div className="card">
                     <div className="text-slate-400 text-sm font-medium mb-1">Total Allocations</div>
                     <div className="text-3xl font-bold text-white">298</div>
                 </div>
                 <div className="card">
                     <div className="text-slate-400 text-sm font-medium mb-1">Network Load</div>
                     <div className="text-3xl font-bold text-white">1.2 <span className="text-slate-500 text-lg font-normal">Gbps</span></div>
                 </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {nodes.map(node => (
                    <div key={node.id} className="card relative overflow-hidden group">
                        <div className={`absolute top-0 left-0 w-1 h-full ${node.status === 'online' ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
                        
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                    {node.name}
                                    {node.status === 'offline' && <div className="icon-triangle-alert text-red-500 w-4 h-4"></div>}
                                </h3>
                                <div className="text-sm text-slate-400 flex items-center gap-1 mt-1">
                                    <div className="icon-map-pin w-3 h-3"></div> {node.location}
                                </div>
                            </div>
                            <button className="text-slate-400 hover:text-white"><div className="icon-more-vertical w-5 h-5"></div></button>
                        </div>

                        <div className="space-y-4 mb-6">
                            <div>
                                <div className="flex justify-between text-xs text-slate-400 mb-1">
                                    <span>RAM Usage</span>
                                    <span>{node.ram.used} / {node.ram.total} GB</span>
                                </div>
                                <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                                    <div 
                                        className={`h-full ${node.status === 'online' ? 'bg-[var(--primary-color)]' : 'bg-slate-700'}`} 
                                        style={{width: `${(node.ram.used / node.ram.total) * 100}%`}}
                                    ></div>
                                </div>
                            </div>
                            <div>
                                <div className="flex justify-between text-xs text-slate-400 mb-1">
                                    <span>Disk Usage</span>
                                    <span>{node.disk.used} / {node.disk.total} GB</span>
                                </div>
                                <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                                    <div 
                                        className={`h-full ${node.status === 'online' ? 'bg-orange-500' : 'bg-slate-700'}`} 
                                        style={{width: `${(node.disk.used / node.disk.total) * 100}%`}}
                                    ></div>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center justify-between text-sm pt-4 border-t border-[var(--border-color)]">
                             <div className="text-slate-400">
                                 <span className="text-white font-bold">{node.servers}</span> Servers
                             </div>
                             <div className="flex gap-2">
                                 <span className="font-mono text-slate-500">{node.ip}</span>
                             </div>
                        </div>
                        
                        <div className="mt-4 flex gap-2">
                            <button className="btn btn-secondary btn-sm flex-1">Configure</button>
                            <button className="btn btn-secondary btn-sm flex-1">Allocations</button>
                        </div>
                    </div>
                ))}
            </div>
        </Layout>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><AdminPage /></ErrorBoundary>);