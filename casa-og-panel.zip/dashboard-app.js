class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) { return { hasError: true }; }
  componentDidCatch(error, errorInfo) { console.error(error, errorInfo); }
  render() { if (this.state.hasError) return <h1>Something went wrong.</h1>; return this.props.children; }
}

function Dashboard() {
    const servers = [
        {
            id: 'srv-01',
            name: 'Survival SMP Season 4',
            game: 'Minecraft Java',
            status: 'online',
            ip: '192.168.1.1',
            port: '25565',
            node: 'Node-NYC-01',
            usage: { cpu: 12, ram: '2.4GB / 8GB', disk: '15GB / 50GB' }
        },
        {
            id: 'srv-02',
            name: 'Creative Plot World',
            game: 'Minecraft Bedrock',
            status: 'offline',
            ip: '192.168.1.1',
            port: '19132',
            node: 'Node-NYC-01',
            usage: { cpu: 0, ram: '0GB / 4GB', disk: '2GB / 20GB' }
        },
        {
            id: 'srv-03',
            name: 'Valheim Private',
            game: 'Valheim',
            status: 'starting',
            ip: '192.168.1.2',
            port: '2456',
            node: 'Node-LON-02',
            usage: { cpu: 85, ram: '1.2GB / 4GB', disk: '4GB / 30GB' }
        }
    ];

    return (
        <Layout activePage="dashboard">
            <div className="mb-8">
                <h1 className="text-2xl font-bold text-white mb-2">My Servers</h1>
                <p className="text-slate-400">Manage and monitor your game instances.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {servers.map(server => (
                    <ServerCard key={server.id} server={server} />
                ))}
            </div>

            <div className="mt-12">
                <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold text-white">Recent Activity</h2>
                    <button className="text-[var(--primary-color)] text-sm hover:underline">View All</button>
                </div>
                <div className="bg-[var(--bg-card)] rounded-lg border border-[var(--border-color)] overflow-hidden">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="bg-slate-900/50 text-slate-400 text-sm">
                                <th className="px-6 py-3 font-medium">Server</th>
                                <th className="px-6 py-3 font-medium">Action</th>
                                <th className="px-6 py-3 font-medium">User</th>
                                <th className="px-6 py-3 font-medium">Time</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-[var(--border-color)]">
                            <tr className="text-sm">
                                <td className="px-6 py-3 text-white">Survival SMP</td>
                                <td className="px-6 py-3 text-emerald-400">Server Started</td>
                                <td className="px-6 py-3 text-slate-300">Alex</td>
                                <td className="px-6 py-3 text-slate-500">2 mins ago</td>
                            </tr>
                            <tr className="text-sm">
                                <td className="px-6 py-3 text-white">Valheim Private</td>
                                <td className="px-6 py-3 text-red-400">Server Stopped</td>
                                <td className="px-6 py-3 text-slate-300">Alex</td>
                                <td className="px-6 py-3 text-slate-500">1 hour ago</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </Layout>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><Dashboard /></ErrorBoundary>);