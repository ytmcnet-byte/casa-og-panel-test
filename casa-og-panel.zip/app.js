// Reuse ErrorBoundary from original app.js if needed, or define simple one here
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError(error) { return { hasError: true }; }
  componentDidCatch(error, errorInfo) { console.error(error, errorInfo); }
  render() { if (this.state.hasError) return <h1>Something went wrong.</h1>; return this.props.children; }
}

function LoginPage() {
    const handleLogin = (e) => {
        e.preventDefault();
        // Mock login
        window.location.href = 'dashboard.html';
    };

    return (
        <AuthLayout title="Welcome Back" subtitle="Sign in to your account">
            <form onSubmit={handleLogin} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Email or Username</label>
                    <input type="text" className="form-input" placeholder="user@example.com" required />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Password</label>
                    <input type="password" className="form-input" placeholder="••••••••" required />
                </div>
                
                <div className="flex items-center justify-between text-sm">
                    <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                        <input type="checkbox" className="rounded bg-slate-700 border-slate-600 text-[var(--primary-color)]" />
                        <span>Remember me</span>
                    </label>
                    <a href="#" className="text-[var(--primary-color)] hover:underline">Forgot password?</a>
                </div>

                <button type="submit" className="btn btn-primary w-full">
                    Sign In
                </button>
            </form>
            
            <div className="mt-6 text-center text-sm text-slate-400">
                Don't have an account? 
                <a href="register.html" className="text-[var(--primary-color)] hover:underline ml-1">Register</a>
            </div>
        </AuthLayout>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><LoginPage /></ErrorBoundary>);